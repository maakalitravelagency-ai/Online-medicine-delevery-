ONLINE MEDICINE DELIVERY WEBSITE
Location: Narsingarh
Offers: 10% discount + No delivery charges

Open index.html in a browser to preview.
To activate WhatsApp ordering, replace the placeholder in the sendOrder() function with your business WhatsApp number.
